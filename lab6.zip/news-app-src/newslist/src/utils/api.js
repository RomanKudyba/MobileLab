import axios from 'axios'

require('es6-promise').polyfill()

let axiosInstance = axios.create({
  baseURL: 'https://newsapi.org/v2'
})

axiosInstance.interceptors.request.use(config => {
  config.headers['X-Api-Key'] = '7116eb85d8ca477a98d4a6f26a425f02'

  return config
})

export default axiosInstance
