// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'

Vue.config.productionTip = false

window.isMobileApp = !!window['cordova'] &&
    document.URL.indexOf('http://') === -1 &&
    document.URL.indexOf('https://') === -1

// require('../node_modules/bootstrap-sass/assets/stylesheets/_bootstrap.scss')

/* eslint-disable no-new */
window.onload = function () {
  if (!window.isMobileApp) {
    try {
      document.dispatchEvent(new window.Event('deviceready'))
    } catch (e) {
      let event = document.createEvent('Event')
      event.initEvent('deviceready', true, false)
    }
  }
}

new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})

document.addEventListener('deviceready', () => {
}, false)
