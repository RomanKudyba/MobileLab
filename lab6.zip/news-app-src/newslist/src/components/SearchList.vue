<template>
  <div class="search-list-wrapper">
    <a href="" class="reload" v-on:click.prevent="reload">
      <span class="glyphicon glyphicon-refresh"></span>
    </a>
    <div class="search-list">
      <div id="filter-button" v-on:click="showFilter" :class="scrolling ? 'scrolled' : ''">
        <span class="glyphicon glyphicon-filter"></span>
      </div>
        <transition
          name="custom-classes-transition"
          enter-active-class="animated zoomInRight"
          leave-active-class="animated zoomOutRight"
        >
        <div role="dialog" tabindex="-1" v-on:click="hideFilter" class="filter-overlay" v-if="filterShown">
          <div class="filter" v-on:click.stop="">
            <div>
              <strong>Category</strong>
              <multiselect
                :multiple="false"
                v-model="chosenCategory"
                :options="categories"
                track-by="code"
                placeholder="Select category"
                label="name">
              </multiselect>
              <strong>Country</strong>
              <multiselect
                :multiple="true"
                :searchable="true"
                v-model="chosenCountires"
                :options="countries"
                placeholder="Select countries"
                :close-on-select="false"
                track-by="code"
                label="name">
              </multiselect>
              <button
                v-on:click.prevent="updateSources"
                class="filter-btn btn btn-default">
                Find News Sources
              </button>
            </div>
            <br />
            <div>
              <strong>Sources (Maximun 20)</strong>
              <multiselect
                :multiple="true"
                :searchable="true"
                v-model="sources"
                :options="requestedSources"
                placeholder="Select news sources"
                :close-on-select="false"
                :max="20"
                track-by="id"
                label="name"
                v-if="!sourcesLoading">
              </multiselect>
              <button v-if="!sourcesLoading"
                v-on:click.prevent="changeFilter"
                class="filter-btn btn btn-default">
                Go For News
              </button>
              <div class="text-center" v-else>
                <span class="glyphicon glyphicon-refresh"></span>
              </div>
            </div>
          </div>
        </div>
      </transition>
      <div class="item row" v-for="(article, index) in list" :key="index">
        <div class="left-panel col-xs-5 col-sm-4 col-md-3">
          <img class="img-rounded img-responsive" :class="!article.urlToImage ? 'no-image' : ''" :src="article.urlToImage" />
        </div>
        <div class="right-panel col-xs-7 col-sm-8 col-md-9">
          <span class="glyphicon glyphicon-time"></span>
          <span v-text="article.publishedAt.substr(0, 10).split('-').reverse().join('.')"></span>
          <span v-text="article.source.name"></span>:
          <a :href="article.url" target="_blank">
            <strong><span v-text="article.title"></span></strong>
          </a>
          <div v-text="article.description"></div>
        </div>
      </div>
      <infinite-loading @infinite="infiniteHandler" ref="infiniteLoading">
        <span slot="no-more">
          There is no more News :(
        </span>
      </infinite-loading>
    </div>
  </div>
</template>

<script>
import API from '@/utils/api'
import InfiniteLoading from 'vue-infinite-loading'
import Multiselect from 'vue-multiselect'

export default {
  name: 'SearchList',
  data () {
    return {
      list: [],
      pageSize: 20,
      limit: 0,
      scrolling: false,
      filterShown: false,
      chosenCategory: null,
      chosenCountires: null,
      categories: [
        {'code': 'business', 'name': 'Business'},
        {'code': 'entertainment', 'name': 'Entertainment'},
        {'code': 'general', 'name': 'General'},
        {'code': 'health', 'name': 'Health'},
        {'code': 'science', 'name': 'Science'},
        {'code': 'sports', 'name': 'Sports'},
        {'code': 'technology', 'name': 'Technology'}
      ],
      countries: [
        {'code': 'ae', 'name': 'United Arab Emirates'},
        {'code': 'ar', 'name': 'Argentina'},
        {'code': 'at', 'name': 'Austria'},
        {'code': 'au', 'name': 'Australia'},
        {'code': 'be', 'name': 'Belgium'},
        {'code': 'bg', 'name': 'Bulgaria'},
        {'code': 'br', 'name': 'Brazil'},
        {'code': 'ca', 'name': 'Canada'},
        {'code': 'ch', 'name': 'Switzerland'},
        {'code': 'cn', 'name': 'China'},
        {'code': 'cu', 'name': 'Cuba'},
        {'code': 'cz', 'name': 'Czech Republic'},
        {'code': 'de', 'name': 'Germany'},
        {'code': 'eg', 'name': 'Egypt'},
        {'code': 'fr', 'name': 'France'},
        {'code': 'gb', 'name': 'United Kingdom'},
        {'code': 'gr', 'name': 'Greece'},
        {'code': 'hk', 'name': 'Hong Kong'},
        {'code': 'hu', 'name': 'Hungary'},
        {'code': 'id', 'name': 'Indonesia'},
        {'code': 'ie', 'name': 'Ireland'},
        {'code': 'il', 'name': 'Israel'},
        {'code': 'in', 'name': 'India'},
        {'code': 'it', 'name': 'Italy'},
        {'code': 'jp', 'name': 'Japan'},
        {'code': 'kr', 'name': 'South Korea'},
        {'code': 'lt', 'name': 'Lithuania'},
        {'code': 'lv', 'name': 'Latvia'},
        {'code': 'ma', 'name': 'Morocco'},
        {'code': 'mx', 'name': 'Mexico'},
        {'code': 'my', 'name': 'Malaysia'},
        {'code': 'ng', 'name': 'Nigeria'},
        {'code': 'nl', 'name': 'Netherlands'},
        {'code': 'no', 'name': 'Norway'},
        {'code': 'nz', 'name': 'New Zealand'},
        {'code': 'ph', 'name': 'Philippines'},
        {'code': 'pl', 'name': 'Poland'},
        {'code': 'pt', 'name': 'Portugal'},
        {'code': 'ro', 'name': 'Romania'},
        {'code': 'rs', 'name': 'Serbia'},
        {'code': 'ru', 'name': 'Russia'},
        {'code': 'sa', 'name': 'Saudi Arabia'},
        {'code': 'se', 'name': 'Sweden'},
        {'code': 'sg', 'name': 'Singapore'},
        {'code': 'si', 'name': 'Slovenia'},
        {'code': 'sk', 'name': 'Slovakia'},
        {'code': 'th', 'name': 'Thailand'},
        {'code': 'tr', 'name': 'Turkey'},
        {'code': 'tw', 'name': 'Taiwan'},
        {'code': 'ua', 'name': 'Ukraine'},
        {'code': 'us', 'name': 'United States'},
        {'code': 've', 'name': 'Venezuela'},
        {'code': 'za', 'name': 'South Africa'}
      ],
      requestedSources: [],
      sources: null,
      sourcesLoading: false
    }
  },
  created () {
    window.addEventListener('scroll', this.onScroll)
    this.scrollTimer = null

    let storedCategory = localStorage.getItem('category')
    if (storedCategory) {
      this.chosenCategory = JSON.parse(storedCategory)
    }

    let storedCountries = localStorage.getItem('countries')
    if (storedCountries) {
      this.chosenCountires = JSON.parse(storedCountries)
    }

    let storedSources = localStorage.getItem('sources')
    if (storedSources) {
      this.sources = JSON.parse(storedSources)
    }
  },
  components: {
    InfiniteLoading,
    Multiselect
  },
  methods: {
    fetchNews (page = 1) {
      let sources = []
      if (this.sources !== null) {
        let length = this.sources.length
        for (let i = 0; i < length; i++) {
          sources.push(this.sources[i].id)
        }
        localStorage.setItem('sources', JSON.stringify(this.sources))
      } else {
        sources.push('bbc-news')
      }

      return API.get(
        '/everything', {
          params: {
            apiKey: this.apiKey,
            page: page,
            pageSize: this.pageSize,
            sources: sources,
            sortBy: 'publishedAt'
          }
        }
      )
    },
    fetchSources (category = '', countries = []) {
      let params = {}
      if (category) {
        params.category = category
      }

      if (countries.length > 0) {
        params.country = countries
      }

      return API.get(
        '/sources', {
          params: params
        }
      )
    },
    infiniteHandler ($state) {
      let page = this.list.length / this.pageSize + 1

      this.fetchNews(page)
        .then(response => {
          let data = response ? response.data : []
          if (data.articles.length > 0) {
            this.list = this.list.concat(data.articles)
            this.$nextTick(function () {
              $state.loaded()
            })
          } else {
            $state.complete()
          }
        })
        .catch(error => {
          console.error(error)
        })
    },
    updateSources () {
      this.sources = null
      this.selectSources()
    },
    selectSources () {
      this.sourcesLoading = true

      let category = ''
      if (this.chosenCategory) {
        category = this.chosenCategory.code
        localStorage.setItem('category', JSON.stringify(this.chosenCategory))
      }

      let countries = []
      if (this.chosenCountires) {
        let length = this.chosenCountires.length
        for (let i = 0; i < length; i++) {
          countries.push(this.chosenCountires[i].code)
        }

        localStorage.setItem('countries', JSON.stringify(this.chosenCountires))
      }

      this.fetchSources(category, countries)
        .then(response => {
          this.requestedSources = response ? response.data.sources : []
        })
        .catch(error => {
          console.error(error)
        })
        .then(() => {
          this.sourcesLoading = false
        })
    },
    changeFilter () {
      this.list = []
      this.$nextTick(() => {
        this.$refs.infiniteLoading.$emit('$InfiniteLoading:reset')
      })
    },
    onScroll () {
      this.scrolling = true

      if (this.scrollTimer !== null) {
        clearTimeout(this.scrollTimer)
      }

      this.scrollTimer = setTimeout(() => { this.scrolling = false }, 500)
    },
    imageLoaded (e) {
      e.target.className = e.target.className.replace('loading', '')
    },
    showFilter () {
      this.filterShown = true
      if (this.requestedSources.length === 0) {
        this.selectSources()
      }
    },
    hideFilter () {
      this.filterShown = false
    },
    reload () {
      window.location.reload()
    }
  }
}
</script>

<style lang="scss" scoped>
.search-list-wrapper {
  .reload {
    position: fixed;
    top: 0;
    right: 5px;
    color: purple;
    padding: 10px;
    font-size: 16px;
    cursor: pointer;
    display: block;
    z-index: 1000;
  }
  .search-list {
    max-width: 800px;
    margin: 0 auto;

    .item {
      position: relative;
      min-height: 100px;
      max-height: 120px;
      overflow: hidden;
      border: 1px solid #cccccc;
      border-radius: 5px;
      margin: 5px 5px;
      padding: 5px 5px;

      .left-panel {
        text-align: center;

        img {
          @media (max-width:468px) {
            margin-top: 1.5em;
          }

          min-width: 80px;
          max-height: 100px;
          display: inline-block;
        }

        .no-image {
          @media (max-width:468px) {
            margin-top: 0;
          }

          background-image: url('../assets/images/icon-image-512.png');
          background-size: 80px 80px;
          background-repeat: no-repeat;
          height: 80px;
          border-radius: 40px;
        }
      }

      .right-panel {
        max-height: 100px;
        text-align: left;
        overflow-y: hidden;
        background: transparent;
        font-size: 10px;
      }

      -webkit-box-shadow: 2px 2px 2px 1px #ccc;  /* Safari 3-4, iOS 4.0.2 - 4.2, Android 2.3+ */
      -moz-box-shadow:    2px 2px 2px 1px #ccc;  /* Firefox 3.5 - 3.6 */
      box-shadow:         2px 2px 2px 1px #ccc;  /* Opera 10.5, IE 9, Firefox 4+, Chrome 6+, iOS 5 */
    }

    #filter-button {
      cursor: pointer;
      position: fixed;
      right: 0;
      bottom: 35%;
      padding: 10px 30px 10px 20px;
      background: purple;
      color: #ffffff;
      border-radius: 20px 0 0 20px;
      font-size: 1.1em;
      z-index: 101;
      -webkit-transition: right 0.5s ease-out; /* Safari */
      transition: right 0.5s ease-out;
    }

    #filter-button.scrolled {
      right: -20px;
    }

    .filter-overlay {
      position: fixed;
      overflow-x: hidden;
      overflow-y: auto;
      opacity: 1;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      z-index: 999;
      -webkit-overflow-scrolling: touch;
      outline: 0;
      background-color: rgba(255, 255, 255, 0);
      transition: opacity 0.3s ease;

      .filter {
        padding: 10px 30px;
        max-width: 500px;
        position: relative;
        margin-top: 40px;
        margin-left: auto;
        margin-right: auto;
        width: calc(100% - 30px);
        z-index: 1000;
        min-height: 300px;
        background: #ffffff;
        -webkit-box-shadow: 2px 2px 2px 1px #ccc;  /* Safari 3-4, iOS 4.0.2 - 4.2, Android 2.3+ */
           -moz-box-shadow: 2px 2px 2px 1px #ccc;  /* Firefox 3.5 - 3.6 */
                box-shadow: 2px 2px 2px 1px #ccc;  /* Opera 10.5, IE 9, Firefox 4+, Chrome 6+, iOS 5 */
      }

      .filter-btn {
        margin-top: 5px;
      }
    }
  }
}
</style>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
