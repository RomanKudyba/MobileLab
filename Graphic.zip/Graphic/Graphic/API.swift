//
//  API.swift
//  Graphic
//
//  Created by Роман К on 5/14/19.
//  Copyright © 2019 Роман К. All rights reserved.
//

import Alamofire

class API {
    static let shared = API()
    
    let header = "X-ba-key: MjUyYjk4MGViMGRmNDQ0OTgxYmFjZTUyOGIxZDcyZWM"
    
    func apiRequest() {
        
    }
}
