//
//  ViewController.swift
//  Graphic
//
//  Created by Роман К on 5/14/19.
//  Copyright © 2019 Роман К. All rights reserved.
//

import UIKit
import Charts

class ViewController: UIViewController {

    var lineChartEntry = [ChartDataEntry]()
    var numbers: [Double] = [Double]()
    @IBOutlet weak var chtChart: LineChartView!
    @IBOutlet weak var textBox: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func addButtonClicked(_ sender: Any) {
        let input  = Double(textBox.text!)
        numbers.append(input!)
        updateGraph()
    }
    
    func updateGraph(){
        var lineChartEntry  = [ChartDataEntry]()
        
        
        //here is the for loop
        for i in 0..<numbers.count {
            
            let value = ChartDataEntry(x: Double(i), y: numbers[i])
            lineChartEntry.append(value)
        }
        
        let line1 = LineChartDataSet(values: lineChartEntry, label: "Number")
        line1.colors = [NSUIColor.blue]
        
        let data = LineChartData()
        data.addDataSet(line1)
        
        
        chtChart.data = data
        chtChart.chartDescription?.text = "My awesome chart"
    }
}

